# Overview
This is a package of Wayne, for packing up some commonly used tools

# Tool list
- load_data: load data from path
- save_data: save data to path
- get_shuffle_index
- online_local_chat

- SingletonLogger

- _PUNCATUATION_EN
- _PUNCATUATION_ZH